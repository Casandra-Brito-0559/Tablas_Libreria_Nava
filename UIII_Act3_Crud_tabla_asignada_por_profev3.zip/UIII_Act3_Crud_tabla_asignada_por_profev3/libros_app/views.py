from django.shortcuts import render, redirect
from .models import Libros
# Create your views here.
def inicio_vista(request):
    loslibros=Libros.objects.all()
    return render(request, 'gestion.html',{'mislibros':loslibros})
    
def registrar(request):
    codigo = request.POST["txtcodigo"]
    titulo = request.POST["txttitulo"]
    autor = request.POST["txtautor"]
    genero = request.POST["txtgenero"]
    presio = request.POST["txtpresio"]
    cantidad = request.POST["numcantidad"]
    fecha = request.POST["datefecha"]

    guardarmateria = Libros.objects.create(codigo=codigo,titulo=titulo,autor=autor,genero=genero,presio=presio,cantidad=cantidad,fecha=fecha)
    return redirect('/')

def seleccionar(request, codigo):
    libro = Libros.objects.get(codigo=codigo)
    return render(request, 'editar.html',{'mislibros':libro})

def editar(request):
    codigo = request.POST["txtcodigo"]
    titulo = request.POST["txttitulo"]
    autor = request.POST["txtautor"]
    genero = request.POST["txtgenero"]
    presio = request.POST["txtpresio"]
    cantidad = request.POST["numcantidad"]
    fecha = request.POST["datefecha"]

    materia = Libros.objects.get(codigo=codigo)
    materia.titulo=titulo
    materia.autor=autor
    materia.genero=genero
    materia.presio=presio
    materia.cantidad=cantidad
    materia.fecha=fecha
    materia.save()
    return redirect('/')

def borrar(request, codigo):
    materia=Libros.objects.get(codigo=codigo)
    materia.delete()
    return redirect("/")
