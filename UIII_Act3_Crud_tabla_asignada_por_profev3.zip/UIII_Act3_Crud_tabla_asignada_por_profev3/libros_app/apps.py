from django.apps import AppConfig


class LibrosAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'libros_app'
