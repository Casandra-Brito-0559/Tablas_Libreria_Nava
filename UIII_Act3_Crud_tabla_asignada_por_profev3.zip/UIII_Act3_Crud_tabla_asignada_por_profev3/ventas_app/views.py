from django.shortcuts import render, redirect
from .models import Ventas
# Create your views here.
def inicio_vista(request):
    losventas=Ventas.objects.all()
    return render(request, 'gestion.html',{'misventas':losventas})
    
def registrar(request):
    codigo = request.POST["txtcodigo"]
    fecha = request.POST["datefecha"]
    codigocli = request.POST["txtcodigocli"]
    cantidad = request.POST["numcantidad"]
    codigolib = request.POST["txtcodigolib"]
    codigisu = request.POST["txtcodigosu"]
    codigoem = request.POST["txtcodigoem"]
    
    

    guardarmateria = Ventas.objects.create(codigo=codigo,fecha=fecha,codigocli=codigocli,cantidad=cantidad,codigolib=codigolib,codigosu=codigisu,codigoem=codigoem)
    return redirect('/')

def seleccionar(request, codigo):
    venta = Ventas.objects.get(codigo=codigo)
    return render(request, 'editar.html',{'misventas':Ventas})

def editar(request):
    codigo = request.POST["txtcodigo"]
    fecha = request.POST["datefecha"]
    codigocli = request.POST["txtcodigocli"]
    cantidad = request.POST["numcantidad"]
    codigolib = request.POST["txtcodigolib"]
    codigisu = request.POST["txtcodigosu"]
    codigoem = request.POST["txtcodigoem"]

    materia = Ventas.objects.get(codigo=codigo)
    materia.fecha=fecha
    materia.codigocli=codigocli 
    materia.codigolib=codigolib
    materia.cantidad=cantidad
    materia.codigosu=codigisu
    materia.codigoem=codigoem
    
    materia.save()
    return redirect('/')

def borrar(request, codigo):
    materia=Ventas.objects.get(codigo=codigo)
    materia.delete()
    return redirect("/")
